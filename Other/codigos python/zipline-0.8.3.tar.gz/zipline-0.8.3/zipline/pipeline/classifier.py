"""
classifier.py
"""

from zipline.pipeline.term import CompositeTerm


class Classifier(CompositeTerm):
    pass
